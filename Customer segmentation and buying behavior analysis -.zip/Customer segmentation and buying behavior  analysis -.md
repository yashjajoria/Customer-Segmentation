#### Customer segmentation and consumer behavior

#### This is a real sales data set of a UK based retailer , all the transaction occurring between 01/12/2010 and 09/12/2011 for a UK - bases , the company mainly sells unique all - occasion gists . many customers of the company are wholeselers.

#### Data source : https://archive.ics.uci.edu/dataset/352/online+retail

### Segment  the customers based on RFM so that the company can target its customers effciently 

### R ( Recency ) - Number of days since last purchase 

### F (Frequency ) - Number of trancsactions 

### M (Monetary) - Total amount of transactions ( revenue contributed)


```python
# Required libraries for clustering 
import numpy as np 
import pandas  as  pd 
import matplotlib.pyplot as plt 
import seaborn as sns 
import datetime as dt 
import sklearn 
from sklearn.preprocessing import StandardScaler 
from sklearn.cluster import KMeans
import warnings 
warnings.filterwarnings('ignore')

```


```python
online_retail = pd.read_excel("D:\yash\Intern\Online Retail.xlsx")
```


```python
online_retail
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>536365</td>
      <td>85123A</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.55</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>1</th>
      <td>536365</td>
      <td>71053</td>
      <td>WHITE METAL LANTERN</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>2</th>
      <td>536365</td>
      <td>84406B</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>8</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.75</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>3</th>
      <td>536365</td>
      <td>84029G</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4</th>
      <td>536365</td>
      <td>84029E</td>
      <td>RED WOOLLY HOTTIE WHITE HEART.</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>541904</th>
      <td>581587</td>
      <td>22613</td>
      <td>PACK OF 20 SPACEBOY NAPKINS</td>
      <td>12</td>
      <td>2011-12-09 12:50:00</td>
      <td>0.85</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541905</th>
      <td>581587</td>
      <td>22899</td>
      <td>CHILDREN'S APRON DOLLY GIRL</td>
      <td>6</td>
      <td>2011-12-09 12:50:00</td>
      <td>2.10</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541906</th>
      <td>581587</td>
      <td>23254</td>
      <td>CHILDRENS CUTLERY DOLLY GIRL</td>
      <td>4</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.15</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541907</th>
      <td>581587</td>
      <td>23255</td>
      <td>CHILDRENS CUTLERY CIRCUS PARADE</td>
      <td>4</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.15</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541908</th>
      <td>581587</td>
      <td>22138</td>
      <td>BAKING SET 9 PIECE RETROSPOT</td>
      <td>3</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.95</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
  </tbody>
</table>
<p>541909 rows × 8 columns</p>
</div>




```python
#shape online_retail
online_retail.shape
```




    (541909, 8)




```python
#info 
online_retail.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 541909 entries, 0 to 541908
    Data columns (total 8 columns):
     #   Column       Non-Null Count   Dtype         
    ---  ------       --------------   -----         
     0   InvoiceNo    541909 non-null  object        
     1   StockCode    541909 non-null  object        
     2   Description  540455 non-null  object        
     3   Quantity     541909 non-null  int64         
     4   InvoiceDate  541909 non-null  datetime64[ns]
     5   UnitPrice    541909 non-null  float64       
     6   CustomerID   406829 non-null  float64       
     7   Country      541909 non-null  object        
    dtypes: datetime64[ns](1), float64(2), int64(1), object(4)
    memory usage: 33.1+ MB
    

# Data cleaning 


```python
# calculating the  missing values % contribution in datarame
```


```python
null = round(100*(online_retail.isnull().sum())/len(online_retail),2)
```


```python
null
```




    InvoiceNo       0.00
    StockCode       0.00
    Description     0.27
    Quantity        0.00
    InvoiceDate     0.00
    UnitPrice       0.00
    CustomerID     24.93
    Country         0.00
    dtype: float64




```python
online_retail = online_retail.dropna()
```


```python
online_retail.shape
```




    (406829, 8)




```python
#changing the datatype od customer id 
online_retail['CustomerID'] = online_retail['CustomerID'].astype(str)
```

    C:\Users\yashj\AppData\Local\Temp\ipykernel_17232\163408905.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      online_retail['CustomerID'] = online_retail['CustomerID'].astype(str)
    

#### New Attribute : Monetary 


```python
online_retail['Amount'] = online_retail['Quantity']*online_retail['UnitPrice']
monetary = online_retail.groupby('CustomerID')['Amount'].sum()
monetary = monetary.reset_index()
monetary

```

    C:\Users\yashj\AppData\Local\Temp\ipykernel_17232\1514426366.py:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      online_retail['Amount'] = online_retail['Quantity']*online_retail['UnitPrice']
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>4310.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>1797.24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>1757.55</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>334.40</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4367</th>
      <td>18280.0</td>
      <td>180.60</td>
    </tr>
    <tr>
      <th>4368</th>
      <td>18281.0</td>
      <td>80.82</td>
    </tr>
    <tr>
      <th>4369</th>
      <td>18282.0</td>
      <td>176.60</td>
    </tr>
    <tr>
      <th>4370</th>
      <td>18283.0</td>
      <td>2094.88</td>
    </tr>
    <tr>
      <th>4371</th>
      <td>18287.0</td>
      <td>1837.28</td>
    </tr>
  </tbody>
</table>
<p>4372 rows × 2 columns</p>
</div>



#### New Attributes : Frequency 


```python
frequency = online_retail.groupby('CustomerID')['InvoiceNo'].count()
frequency = frequency.reset_index()
frequency.columns = ['CustomerID' , 'frequency']
frequency.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>frequency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>182</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>31</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>73</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>17</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Merging the two Attibutes 
```


```python
rfm = pd.merge(monetary,frequency , on='CustomerID' , how = 'inner') # base on CustomerID , merge - inner merge 
```


```python
rfm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Amount</th>
      <th>frequency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>0.00</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>4310.00</td>
      <td>182</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>1797.24</td>
      <td>31</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>1757.55</td>
      <td>73</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>334.40</td>
      <td>17</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4367</th>
      <td>18280.0</td>
      <td>180.60</td>
      <td>10</td>
    </tr>
    <tr>
      <th>4368</th>
      <td>18281.0</td>
      <td>80.82</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4369</th>
      <td>18282.0</td>
      <td>176.60</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4370</th>
      <td>18283.0</td>
      <td>2094.88</td>
      <td>756</td>
    </tr>
    <tr>
      <th>4371</th>
      <td>18287.0</td>
      <td>1837.28</td>
      <td>70</td>
    </tr>
  </tbody>
</table>
<p>4372 rows × 3 columns</p>
</div>



#### New Attributes : Recency 
#### Convert to datetime to proper datatype 


```python
online_retail['InvoiceDate'] = pd.to_datetime(online_retail['InvoiceDate'],format='%d-%m-%y %H:%M')
```

    C:\Users\yashj\AppData\Local\Temp\ipykernel_17232\2276734828.py:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      online_retail['InvoiceDate'] = pd.to_datetime(online_retail['InvoiceDate'],format='%d-%m-%y %H:%M')
    


```python
online_retail['InvoiceDate']
```




    0        2010-12-01 08:26:00
    1        2010-12-01 08:26:00
    2        2010-12-01 08:26:00
    3        2010-12-01 08:26:00
    4        2010-12-01 08:26:00
                     ...        
    541904   2011-12-09 12:50:00
    541905   2011-12-09 12:50:00
    541906   2011-12-09 12:50:00
    541907   2011-12-09 12:50:00
    541908   2011-12-09 12:50:00
    Name: InvoiceDate, Length: 406829, dtype: datetime64[ns]




```python
#compute the maximum date  to know the last transaction date 
max_date = max(online_retail['InvoiceDate'])
max_date
```




    Timestamp('2011-12-09 12:50:00')




```python
#Compute the difference between max date and  transcsaction date 
online_retail['dif'] = max_date - online_retail['InvoiceDate']
online_retail
```

    C:\Users\yashj\AppData\Local\Temp\ipykernel_17232\4209938714.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      online_retail['dif'] = max_date - online_retail['InvoiceDate']
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>536365</td>
      <td>85123A</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.55</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>15.30</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>536365</td>
      <td>71053</td>
      <td>WHITE METAL LANTERN</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>536365</td>
      <td>84406B</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>8</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.75</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>22.00</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>536365</td>
      <td>84029G</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>536365</td>
      <td>84029E</td>
      <td>RED WOOLLY HOTTIE WHITE HEART.</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>541904</th>
      <td>581587</td>
      <td>22613</td>
      <td>PACK OF 20 SPACEBOY NAPKINS</td>
      <td>12</td>
      <td>2011-12-09 12:50:00</td>
      <td>0.85</td>
      <td>12680.0</td>
      <td>France</td>
      <td>10.20</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541905</th>
      <td>581587</td>
      <td>22899</td>
      <td>CHILDREN'S APRON DOLLY GIRL</td>
      <td>6</td>
      <td>2011-12-09 12:50:00</td>
      <td>2.10</td>
      <td>12680.0</td>
      <td>France</td>
      <td>12.60</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541906</th>
      <td>581587</td>
      <td>23254</td>
      <td>CHILDRENS CUTLERY DOLLY GIRL</td>
      <td>4</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.15</td>
      <td>12680.0</td>
      <td>France</td>
      <td>16.60</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541907</th>
      <td>581587</td>
      <td>23255</td>
      <td>CHILDRENS CUTLERY CIRCUS PARADE</td>
      <td>4</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.15</td>
      <td>12680.0</td>
      <td>France</td>
      <td>16.60</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541908</th>
      <td>581587</td>
      <td>22138</td>
      <td>BAKING SET 9 PIECE RETROSPOT</td>
      <td>3</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.95</td>
      <td>12680.0</td>
      <td>France</td>
      <td>14.85</td>
      <td>0 days 00:00:00</td>
    </tr>
  </tbody>
</table>
<p>406829 rows × 10 columns</p>
</div>




```python
recency= online_retail.groupby('CustomerID')['dif'].min()
recency = recency.reset_index()
recency.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>dif</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>325 days 02:33:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>1 days 20:58:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>74 days 23:37:00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>18 days 02:59:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>309 days 20:49:00</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Extract number of days only 
recency['dif'] = recency['dif'].dt.days 
recency.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>dif</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>325</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>74</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>18</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>309</td>
    </tr>
  </tbody>
</table>
</div>




```python
rfm = pd.merge(rfm,recency, on =
               'CustomerID' , how = 'inner')
rfm.columns = ['CustomerID','Amount','frequency','Recency']
rfm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Amount</th>
      <th>frequency</th>
      <th>Recency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>0.00</td>
      <td>2</td>
      <td>325</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>4310.00</td>
      <td>182</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>1797.24</td>
      <td>31</td>
      <td>74</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>1757.55</td>
      <td>73</td>
      <td>18</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>334.40</td>
      <td>17</td>
      <td>309</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4367</th>
      <td>18280.0</td>
      <td>180.60</td>
      <td>10</td>
      <td>277</td>
    </tr>
    <tr>
      <th>4368</th>
      <td>18281.0</td>
      <td>80.82</td>
      <td>7</td>
      <td>180</td>
    </tr>
    <tr>
      <th>4369</th>
      <td>18282.0</td>
      <td>176.60</td>
      <td>13</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4370</th>
      <td>18283.0</td>
      <td>2094.88</td>
      <td>756</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4371</th>
      <td>18287.0</td>
      <td>1837.28</td>
      <td>70</td>
      <td>42</td>
    </tr>
  </tbody>
</table>
<p>4372 rows × 4 columns</p>
</div>




```python
#Outlier analysis of amount,frequency,recency 
attributes = ['Amount','frequency','Recency']
sns.boxplot(data = rfm[attributes])
plt.title('Outliers')
plt.ylabel('Range')
plt.xlabel('Attributes',fontweight = 'bold')
```




    Text(0.5, 0, 'Attributes')




    
![png](output_34_1.png)
    



```python
#Outlier analysis of amount,frequency,recency 
attributes = ['Amount','frequency','Recency']
plt.rcParams['figure.figsize'] = [10,8]
sns.boxplot(data = rfm[attributes] , orient = "v",palette = "Set2" , whis = 1.5 , saturation = 1 , width = 0.7)
plt.title('Outliers',fontsize = 14 ,fontweight='bold')
plt.ylabel('Range',fontweight = 'bold')
plt.xlabel('Attributes',fontweight = 'bold')
```




    Text(0.5, 0, 'Attributes')




    
![png](output_35_1.png)
    



```python
Q1 = rfm.Amount.quantile(0.05)
Q3 = rfm.Amount.quantile(0.95)
IQR = Q3 - Q1 
rfm = rfm[(rfm.Amount >= Q1 - 1.5* IQR) & ( rfm.Amount <= Q3 + 1.5*IQR)]


Q1 = rfm.Recency.quantile(0.05)
Q3 =  rfm.Recency.quantile(0.95)
IQR = Q3 - Q1
rfm = rfm[(rfm.Recency >= Q1 - 1.5* IQR) & ( rfm.Recency <= Q3 + 1.5*IQR)]


Q1 = rfm.frequency.quantile(0.05)
Q3 = rfm.frequency.quantile(0.95)
IQR = Q3 - Q1 
rfm = rfm[(rfm.frequency >=Q1 - 1.5*IQR) & (rfm.frequency <= Q3 + 1.5* IQR)]
```

## Scaling 


```python
#our machine learing model d'not byus for high value like amount
```


```python
rfm_df = rfm[['Amount','Recency','frequency']]
scaler = StandardScaler()
#fit_transform
rfm_df_scaled = scaler.fit_transform(rfm_df)
rfm_df_scaled.shape
```




    (4293, 3)



## Model Building

### Elbow method for  right numbers  of clusters 


```python
wssd = []
range_n_clusters = [2,3,4,5,6,7,8]
for num_clusters in range_n_clusters:
    kmeans = KMeans(n_clusters=num_clusters,max_iter = 50)
    kmeans.fit(rfm_df_scaled)
    
    wssd.append(kmeans.inertia_)
    
plt.plot(wssd)
```

    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\yashj\anaconda3\Lib\site-packages\joblib\externals\loky\backend\context.py:110: UserWarning: Could not find the number of physical cores for the following reason:
    found 0 physical cores < 1
    Returning the number of logical cores instead. You can silence this warning by setting LOKY_MAX_CPU_COUNT to the number of cores you want to use.
      warnings.warn(
      File "C:\Users\yashj\anaconda3\Lib\site-packages\joblib\externals\loky\backend\context.py", line 217, in _count_physical_cores
        raise ValueError(
    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    




    [<matplotlib.lines.Line2D at 0x23d4c4d0a10>]




    
![png](output_42_2.png)
    



```python
# In the  particular case use  2,3 number  of cluster 
```

#### FInal model with k = 3 


```python
kmeans = KMeans(n_clusters=3 , max_iter = 300)
kmeans.fit(rfm_df_scaled)
```

    C:\Users\yashj\anaconda3\Lib\site-packages\sklearn\cluster\_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    




<style>#sk-container-id-1 {color: black;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>KMeans(n_clusters=3)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">KMeans</label><div class="sk-toggleable__content"><pre>KMeans(n_clusters=3)</pre></div></div></div></div></div>




```python
kmeans.labels_ #data labling (decide to belong data for cluster)
```




    array([0, 1, 2, ..., 0, 2, 2])




```python
kmeans.predict(rfm_df_scaled)
```




    array([0, 1, 2, ..., 0, 2, 2])




```python
#assign the label 
rfm['Cluster_Id'] = kmeans.predict(rfm_df_scaled)
rfm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Amount</th>
      <th>frequency</th>
      <th>Recency</th>
      <th>Cluster_Id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>0.00</td>
      <td>2</td>
      <td>325</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>4310.00</td>
      <td>182</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>1797.24</td>
      <td>31</td>
      <td>74</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>1757.55</td>
      <td>73</td>
      <td>18</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>334.40</td>
      <td>17</td>
      <td>309</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
rfm.head(100)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Amount</th>
      <th>frequency</th>
      <th>Recency</th>
      <th>Cluster_Id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12346.0</td>
      <td>0.00</td>
      <td>2</td>
      <td>325</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12347.0</td>
      <td>4310.00</td>
      <td>182</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12348.0</td>
      <td>1797.24</td>
      <td>31</td>
      <td>74</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12349.0</td>
      <td>1757.55</td>
      <td>73</td>
      <td>18</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12350.0</td>
      <td>334.40</td>
      <td>17</td>
      <td>309</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>96</th>
      <td>12463.0</td>
      <td>1303.63</td>
      <td>88</td>
      <td>45</td>
      <td>2</td>
    </tr>
    <tr>
      <th>97</th>
      <td>12464.0</td>
      <td>1212.05</td>
      <td>29</td>
      <td>9</td>
      <td>2</td>
    </tr>
    <tr>
      <th>98</th>
      <td>12465.0</td>
      <td>733.89</td>
      <td>51</td>
      <td>7</td>
      <td>2</td>
    </tr>
    <tr>
      <th>99</th>
      <td>12468.0</td>
      <td>724.04</td>
      <td>40</td>
      <td>142</td>
      <td>2</td>
    </tr>
    <tr>
      <th>101</th>
      <td>12472.0</td>
      <td>6229.48</td>
      <td>391</td>
      <td>30</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 5 columns</p>
</div>




```python
#box plot cluster id vs amount 
sns.stripplot(x = 'Cluster_Id' , y = 'Amount' , data = rfm)



# number 1 cluster  people are investing more money
```




    <Axes: xlabel='Cluster_Id', ylabel='Amount'>




    
![png](output_50_1.png)
    



```python
sns.stripplot(x='Cluster_Id' , y ='frequency' ,  data = rfm)
# number 1 cluster  people are frequently buy
```




    <Axes: xlabel='Cluster_Id', ylabel='frequency'>




    
![png](output_51_1.png)
    



```python
sns.stripplot(x='Cluster_Id',y='Recency' , data = rfm)
# number 1 cluster  people low receny 
```




    <Axes: xlabel='Cluster_Id', ylabel='Recency'>




    
![png](output_52_1.png)
    


The k-means clustering algorithm being a un-supervised learning algorithm, we can perform a quick visual check on the model's performance based on the visualization chart.

#### Business Strategy:

cluster 1 may already be dominated by other , can try to increaese sales in the 2 other cluster ( 0 & 2) through suitable competitive positioning, pricing stratgey, cohesive sales & marketing efforts, promotions, bundling etc.
Also cluster 1 important - try to more increaese sales through suitable  marketing efforts, promotions, bundling 
 

Customer segment  0 & 2 have opportunities for growth and future expansion

## Buying Analysis


```python
online_retail

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>536365</td>
      <td>85123A</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.55</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>15.30</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>536365</td>
      <td>71053</td>
      <td>WHITE METAL LANTERN</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>536365</td>
      <td>84406B</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>8</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.75</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>22.00</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>536365</td>
      <td>84029G</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>536365</td>
      <td>84029E</td>
      <td>RED WOOLLY HOTTIE WHITE HEART.</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>541904</th>
      <td>581587</td>
      <td>22613</td>
      <td>PACK OF 20 SPACEBOY NAPKINS</td>
      <td>12</td>
      <td>2011-12-09 12:50:00</td>
      <td>0.85</td>
      <td>12680.0</td>
      <td>France</td>
      <td>10.20</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541905</th>
      <td>581587</td>
      <td>22899</td>
      <td>CHILDREN'S APRON DOLLY GIRL</td>
      <td>6</td>
      <td>2011-12-09 12:50:00</td>
      <td>2.10</td>
      <td>12680.0</td>
      <td>France</td>
      <td>12.60</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541906</th>
      <td>581587</td>
      <td>23254</td>
      <td>CHILDRENS CUTLERY DOLLY GIRL</td>
      <td>4</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.15</td>
      <td>12680.0</td>
      <td>France</td>
      <td>16.60</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541907</th>
      <td>581587</td>
      <td>23255</td>
      <td>CHILDRENS CUTLERY CIRCUS PARADE</td>
      <td>4</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.15</td>
      <td>12680.0</td>
      <td>France</td>
      <td>16.60</td>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>541908</th>
      <td>581587</td>
      <td>22138</td>
      <td>BAKING SET 9 PIECE RETROSPOT</td>
      <td>3</td>
      <td>2011-12-09 12:50:00</td>
      <td>4.95</td>
      <td>12680.0</td>
      <td>France</td>
      <td>14.85</td>
      <td>0 days 00:00:00</td>
    </tr>
  </tbody>
</table>
<p>406829 rows × 10 columns</p>
</div>




```python
# Removing missing data

online_retail = online_retail.dropna()
online_retail.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 406829 entries, 0 to 541908
    Data columns (total 10 columns):
     #   Column       Non-Null Count   Dtype          
    ---  ------       --------------   -----          
     0   InvoiceNo    406829 non-null  object         
     1   StockCode    406829 non-null  object         
     2   Description  406829 non-null  object         
     3   Quantity     406829 non-null  int64          
     4   InvoiceDate  406829 non-null  datetime64[ns] 
     5   UnitPrice    406829 non-null  float64        
     6   CustomerID   406829 non-null  object         
     7   Country      406829 non-null  object         
     8   Amount       406829 non-null  float64        
     9   dif          406829 non-null  timedelta64[ns]
    dtypes: datetime64[ns](1), float64(2), int64(1), object(5), timedelta64[ns](1)
    memory usage: 34.1+ MB
    


```python
# Quantity
online_retail.sort_values("Quantity", ascending = False).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>540421</th>
      <td>581483</td>
      <td>23843</td>
      <td>PAPER CRAFT , LITTLE BIRDIE</td>
      <td>80995</td>
      <td>2011-12-09 09:15:00</td>
      <td>2.08</td>
      <td>16446.0</td>
      <td>United Kingdom</td>
      <td>168469.6</td>
      <td>0 days 03:35:00</td>
    </tr>
    <tr>
      <th>61619</th>
      <td>541431</td>
      <td>23166</td>
      <td>MEDIUM CERAMIC TOP STORAGE JAR</td>
      <td>74215</td>
      <td>2011-01-18 10:01:00</td>
      <td>1.04</td>
      <td>12346.0</td>
      <td>United Kingdom</td>
      <td>77183.6</td>
      <td>325 days 02:49:00</td>
    </tr>
    <tr>
      <th>502122</th>
      <td>578841</td>
      <td>84826</td>
      <td>ASSTD DESIGN 3D PAPER STICKERS</td>
      <td>12540</td>
      <td>2011-11-25 15:57:00</td>
      <td>0.00</td>
      <td>13256.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>13 days 20:53:00</td>
    </tr>
    <tr>
      <th>421632</th>
      <td>573008</td>
      <td>84077</td>
      <td>WORLD WAR 2 GLIDERS ASSTD DESIGNS</td>
      <td>4800</td>
      <td>2011-10-27 12:26:00</td>
      <td>0.21</td>
      <td>12901.0</td>
      <td>United Kingdom</td>
      <td>1008.0</td>
      <td>43 days 00:24:00</td>
    </tr>
    <tr>
      <th>206121</th>
      <td>554868</td>
      <td>22197</td>
      <td>SMALL POPCORN HOLDER</td>
      <td>4300</td>
      <td>2011-05-27 10:52:00</td>
      <td>0.72</td>
      <td>13135.0</td>
      <td>United Kingdom</td>
      <td>3096.0</td>
      <td>196 days 01:58:00</td>
    </tr>
  </tbody>
</table>
</div>




```python
online_retail.sort_values("Quantity", ascending = False).tail(5)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>160144</th>
      <td>C550456</td>
      <td>21175</td>
      <td>GIN + TONIC DIET METAL SIGN</td>
      <td>-2000</td>
      <td>2011-04-18 13:08:00</td>
      <td>1.85</td>
      <td>15749.0</td>
      <td>United Kingdom</td>
      <td>-3700.0</td>
      <td>234 days 23:42:00</td>
    </tr>
    <tr>
      <th>160145</th>
      <td>C550456</td>
      <td>21108</td>
      <td>FAIRY CAKE FLANNEL ASSORTED COLOUR</td>
      <td>-3114</td>
      <td>2011-04-18 13:08:00</td>
      <td>2.10</td>
      <td>15749.0</td>
      <td>United Kingdom</td>
      <td>-6539.4</td>
      <td>234 days 23:42:00</td>
    </tr>
    <tr>
      <th>4287</th>
      <td>C536757</td>
      <td>84347</td>
      <td>ROTATING SILVER ANGELS T-LIGHT HLDR</td>
      <td>-9360</td>
      <td>2010-12-02 14:23:00</td>
      <td>0.03</td>
      <td>15838.0</td>
      <td>United Kingdom</td>
      <td>-280.8</td>
      <td>371 days 22:27:00</td>
    </tr>
    <tr>
      <th>61624</th>
      <td>C541433</td>
      <td>23166</td>
      <td>MEDIUM CERAMIC TOP STORAGE JAR</td>
      <td>-74215</td>
      <td>2011-01-18 10:17:00</td>
      <td>1.04</td>
      <td>12346.0</td>
      <td>United Kingdom</td>
      <td>-77183.6</td>
      <td>325 days 02:33:00</td>
    </tr>
    <tr>
      <th>540422</th>
      <td>C581484</td>
      <td>23843</td>
      <td>PAPER CRAFT , LITTLE BIRDIE</td>
      <td>-80995</td>
      <td>2011-12-09 09:27:00</td>
      <td>2.08</td>
      <td>16446.0</td>
      <td>United Kingdom</td>
      <td>-168469.6</td>
      <td>0 days 03:23:00</td>
    </tr>
  </tbody>
</table>
</div>



Quantity is negative may be due to discounts, damaged goods, thrown away etc. I shall remove these values.


```python
mask = online_retail["Quantity"] > 0

online_retail = online_retail [mask]
online_retail.sort_values("Quantity", ascending = False).tail(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>389620</th>
      <td>570482</td>
      <td>23380</td>
      <td>PACK OF 12 VINTAGE DOILY TISSUES</td>
      <td>1</td>
      <td>2011-10-10 17:00:00</td>
      <td>0.39</td>
      <td>17459.0</td>
      <td>United Kingdom</td>
      <td>0.39</td>
      <td>59 days 19:50:00</td>
    </tr>
    <tr>
      <th>132735</th>
      <td>547689</td>
      <td>21528</td>
      <td>DAIRY MAID TRADITIONAL TEAPOT</td>
      <td>1</td>
      <td>2011-03-24 14:55:00</td>
      <td>6.95</td>
      <td>17757.0</td>
      <td>United Kingdom</td>
      <td>6.95</td>
      <td>259 days 21:55:00</td>
    </tr>
    <tr>
      <th>389621</th>
      <td>570482</td>
      <td>22615</td>
      <td>PACK OF 12 CIRCUS PARADE TISSUES</td>
      <td>1</td>
      <td>2011-10-10 17:00:00</td>
      <td>0.39</td>
      <td>17459.0</td>
      <td>United Kingdom</td>
      <td>0.39</td>
      <td>59 days 19:50:00</td>
    </tr>
    <tr>
      <th>389622</th>
      <td>570482</td>
      <td>23377</td>
      <td>PACK OF 12 DOLLY GIRL TISSUES</td>
      <td>1</td>
      <td>2011-10-10 17:00:00</td>
      <td>0.39</td>
      <td>17459.0</td>
      <td>United Kingdom</td>
      <td>0.39</td>
      <td>59 days 19:50:00</td>
    </tr>
    <tr>
      <th>109150</th>
      <td>545587</td>
      <td>21870</td>
      <td>I CAN ONLY PLEASE ONE PERSON MUG</td>
      <td>1</td>
      <td>2011-03-04 09:46:00</td>
      <td>1.25</td>
      <td>14796.0</td>
      <td>United Kingdom</td>
      <td>1.25</td>
      <td>280 days 03:04:00</td>
    </tr>
  </tbody>
</table>
</div>




```python
# For some customers, their information on country is unspecified, lets filter those out

mask = online_retail["Country"] != "Unspecified"
online_retail = online_retail[mask]
```


```python
# Creating new column - Revenue in $

online_retail["Revenue"] = online_retail["Quantity"]*online_retail["UnitPrice"]
online_retail.head(10).sort_values("Revenue", ascending = False).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9</th>
      <td>536367</td>
      <td>84879</td>
      <td>ASSORTED COLOUR BIRD ORNAMENT</td>
      <td>32</td>
      <td>2010-12-01 08:34:00</td>
      <td>1.69</td>
      <td>13047.0</td>
      <td>United Kingdom</td>
      <td>54.08</td>
      <td>373 days 04:16:00</td>
      <td>54.08</td>
    </tr>
    <tr>
      <th>6</th>
      <td>536365</td>
      <td>21730</td>
      <td>GLASS STAR FROSTED T-LIGHT HOLDER</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>4.25</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>25.50</td>
      <td>373 days 04:24:00</td>
      <td>25.50</td>
    </tr>
    <tr>
      <th>2</th>
      <td>536365</td>
      <td>84406B</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>8</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.75</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>22.00</td>
      <td>373 days 04:24:00</td>
      <td>22.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>536365</td>
      <td>71053</td>
      <td>WHITE METAL LANTERN</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
      <td>20.34</td>
    </tr>
    <tr>
      <th>3</th>
      <td>536365</td>
      <td>84029G</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
      <td>20.34</td>
      <td>373 days 04:24:00</td>
      <td>20.34</td>
    </tr>
  </tbody>
</table>
</div>




```python
online_retail.sort_values("Revenue", ascending = False).tail(5)

# Revenue is 0 for some quantities, as they may have been given away as promotional offers, I shll remove these as well
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>145208</th>
      <td>548871</td>
      <td>22162</td>
      <td>HEART GARLAND RUSTIC PADDED</td>
      <td>2</td>
      <td>2011-04-04 14:42:00</td>
      <td>0.0</td>
      <td>14410.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>248 days 22:08:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>485985</th>
      <td>577696</td>
      <td>M</td>
      <td>Manual</td>
      <td>1</td>
      <td>2011-11-21 11:57:00</td>
      <td>0.0</td>
      <td>16406.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>18 days 00:53:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>454463</th>
      <td>575579</td>
      <td>22437</td>
      <td>SET OF 9 BLACK SKULL BALLOONS</td>
      <td>20</td>
      <td>2011-11-10 11:49:00</td>
      <td>0.0</td>
      <td>13081.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>29 days 01:01:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>454464</th>
      <td>575579</td>
      <td>22089</td>
      <td>PAPER BUNTING VINTAGE PAISLEY</td>
      <td>24</td>
      <td>2011-11-10 11:49:00</td>
      <td>0.0</td>
      <td>13081.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>29 days 01:01:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>285657</th>
      <td>561916</td>
      <td>M</td>
      <td>Manual</td>
      <td>1</td>
      <td>2011-08-01 11:44:00</td>
      <td>0.0</td>
      <td>15581.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>130 days 01:06:00</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
mask = online_retail["Revenue"] > 0

dataset = online_retail [mask]
online_retail.sort_values("Revenue", ascending = False).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>540421</th>
      <td>581483</td>
      <td>23843</td>
      <td>PAPER CRAFT , LITTLE BIRDIE</td>
      <td>80995</td>
      <td>2011-12-09 09:15:00</td>
      <td>2.08</td>
      <td>16446.0</td>
      <td>United Kingdom</td>
      <td>168469.60</td>
      <td>0 days 03:35:00</td>
      <td>168469.60</td>
    </tr>
    <tr>
      <th>61619</th>
      <td>541431</td>
      <td>23166</td>
      <td>MEDIUM CERAMIC TOP STORAGE JAR</td>
      <td>74215</td>
      <td>2011-01-18 10:01:00</td>
      <td>1.04</td>
      <td>12346.0</td>
      <td>United Kingdom</td>
      <td>77183.60</td>
      <td>325 days 02:49:00</td>
      <td>77183.60</td>
    </tr>
    <tr>
      <th>222680</th>
      <td>556444</td>
      <td>22502</td>
      <td>PICNIC BASKET WICKER 60 PIECES</td>
      <td>60</td>
      <td>2011-06-10 15:28:00</td>
      <td>649.50</td>
      <td>15098.0</td>
      <td>United Kingdom</td>
      <td>38970.00</td>
      <td>181 days 21:22:00</td>
      <td>38970.00</td>
    </tr>
    <tr>
      <th>173382</th>
      <td>551697</td>
      <td>POST</td>
      <td>POSTAGE</td>
      <td>1</td>
      <td>2011-05-03 13:46:00</td>
      <td>8142.75</td>
      <td>16029.0</td>
      <td>United Kingdom</td>
      <td>8142.75</td>
      <td>219 days 23:04:00</td>
      <td>8142.75</td>
    </tr>
    <tr>
      <th>348325</th>
      <td>567423</td>
      <td>23243</td>
      <td>SET OF TEA COFFEE SUGAR TINS PANTRY</td>
      <td>1412</td>
      <td>2011-09-20 11:05:00</td>
      <td>5.06</td>
      <td>17450.0</td>
      <td>United Kingdom</td>
      <td>7144.72</td>
      <td>80 days 01:45:00</td>
      <td>7144.72</td>
    </tr>
  </tbody>
</table>
</div>




```python
online_retail.sort_values("Revenue", ascending = False).tail(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
      <th>Amount</th>
      <th>dif</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>145208</th>
      <td>548871</td>
      <td>22162</td>
      <td>HEART GARLAND RUSTIC PADDED</td>
      <td>2</td>
      <td>2011-04-04 14:42:00</td>
      <td>0.0</td>
      <td>14410.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>248 days 22:08:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>485985</th>
      <td>577696</td>
      <td>M</td>
      <td>Manual</td>
      <td>1</td>
      <td>2011-11-21 11:57:00</td>
      <td>0.0</td>
      <td>16406.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>18 days 00:53:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>454463</th>
      <td>575579</td>
      <td>22437</td>
      <td>SET OF 9 BLACK SKULL BALLOONS</td>
      <td>20</td>
      <td>2011-11-10 11:49:00</td>
      <td>0.0</td>
      <td>13081.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>29 days 01:01:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>454464</th>
      <td>575579</td>
      <td>22089</td>
      <td>PAPER BUNTING VINTAGE PAISLEY</td>
      <td>24</td>
      <td>2011-11-10 11:49:00</td>
      <td>0.0</td>
      <td>13081.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>29 days 01:01:00</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>285657</th>
      <td>561916</td>
      <td>M</td>
      <td>Manual</td>
      <td>1</td>
      <td>2011-08-01 11:44:00</td>
      <td>0.0</td>
      <td>15581.0</td>
      <td>United Kingdom</td>
      <td>0.0</td>
      <td>130 days 01:06:00</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
dataset["StockCode"] = dataset["StockCode"].astype('object')
dataset["CustomerID"] = dataset["CustomerID"].astype('object')

dataset.info()
```

    C:\Users\yashj\AppData\Local\Temp\ipykernel_17232\3948094610.py:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      dataset["StockCode"] = dataset["StockCode"].astype('object')
    C:\Users\yashj\AppData\Local\Temp\ipykernel_17232\3948094610.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      dataset["CustomerID"] = dataset["CustomerID"].astype('object')
    

    <class 'pandas.core.frame.DataFrame'>
    Index: 397640 entries, 0 to 541908
    Data columns (total 11 columns):
     #   Column       Non-Null Count   Dtype          
    ---  ------       --------------   -----          
     0   InvoiceNo    397640 non-null  object         
     1   StockCode    397640 non-null  object         
     2   Description  397640 non-null  object         
     3   Quantity     397640 non-null  int64          
     4   InvoiceDate  397640 non-null  datetime64[ns] 
     5   UnitPrice    397640 non-null  float64        
     6   CustomerID   397640 non-null  object         
     7   Country      397640 non-null  object         
     8   Amount       397640 non-null  float64        
     9   dif          397640 non-null  timedelta64[ns]
     10  Revenue      397640 non-null  float64        
    dtypes: datetime64[ns](1), float64(3), int64(1), object(5), timedelta64[ns](1)
    memory usage: 36.4+ MB
    


```python
# Customer ID

print("Top 20% of customers driving 80% of revenue:")
online_retail["CustomerID"].nunique()

online_retail.groupby("CustomerID").agg({"Revenue": "sum"}).sort_values("Revenue", ascending = False).head(20).plot(kind = "bar")
                                
plt.show()
```

    Top 20% of customers driving 80% of revenue:
    


    
![png](output_70_1.png)
    



```python
# Customer IDs of top segments

dataset1 = online_retail[["CustomerID", "Revenue"]]

print("Top customer segment IDs")
dataset2 = dataset1.groupby("CustomerID").agg({"Revenue": "sum"}).sort_values("Revenue", ascending = False)

dataset2.head(5)
```

    Top customer segment IDs
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Revenue</th>
    </tr>
    <tr>
      <th>CustomerID</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>14646.0</th>
      <td>280206.02</td>
    </tr>
    <tr>
      <th>18102.0</th>
      <td>259657.30</td>
    </tr>
    <tr>
      <th>17450.0</th>
      <td>194550.79</td>
    </tr>
    <tr>
      <th>16446.0</th>
      <td>168472.50</td>
    </tr>
    <tr>
      <th>14911.0</th>
      <td>143825.06</td>
    </tr>
  </tbody>
</table>
</div>




```python

h = dataset1["CustomerID"].nunique()
i = round(0.25*h)
print("# of customers in top 25% power segment:", i, "out of", h)

j = dataset1.groupby("CustomerID").agg({"Revenue": "sum"}).sort_values("Revenue", ascending = False).head(i).sum()
k = dataset1["Revenue"].sum()

l = j/k*100
print("Total sales resulting from the top product segment:", round(list(l)[0]), "%")
```

    # of customers in top 25% power segment: 1084 out of 4335
    Total sales resulting from the top product segment: 79 %
    

1084 out of total 3877, top 25% of customer segments result in 79% of total $ sales amount.

While the top 25 % customers can be targetted for potential up sell and cross sell potential.

Considering that the retail industry is very competitive, the remaining 75% of customers can be targetted for future expansion by coordination with sales & marketing teams, discounts, pricing stratagy, bundling products, etc.


```python
# Segmenting sales by geographic location

dataset1 = dataset[["Country", "Revenue"]]

print("Countries:")
dataset1["Country"].nunique()
print("Top 10 countries by $ sales:")
dataset2 = dataset1.groupby("Country").agg({"Revenue": "sum"}).sort_values("Revenue", ascending = False)
dataset2.head(5).plot(kind = "bar")
```

    Countries:
    Top 10 countries by $ sales:
    




    <Axes: xlabel='Country'>




    
![png](output_75_2.png)
    



```python
print("Bottom 10 countries by $ sales:")

dataset2.tail(10).plot(kind = "bar")

# Analysis
```

    Bottom 10 countries by $ sales:
    




    <Axes: xlabel='Country'>




    
![png](output_76_2.png)
    



```python
# Identifying the top 20 % geographic locations driving 80 % of $ sales

h = dataset1["Country"].nunique()
i = 1

print("# of products in UK:")

j = dataset2.head(i).sum()
k = dataset1["Revenue"].sum()

l = j/k*100
print("Total $ sales resulting from UK:", round(list(l)[0]), "%")
```

    # of products in UK:
    Total $ sales resulting from UK: 82 %
    


```python
dataset2.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Revenue</th>
    </tr>
    <tr>
      <th>Country</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>United Kingdom</th>
      <td>7308391.554</td>
    </tr>
    <tr>
      <th>Netherlands</th>
      <td>285446.340</td>
    </tr>
    <tr>
      <th>EIRE</th>
      <td>265545.900</td>
    </tr>
    <tr>
      <th>Germany</th>
      <td>228867.140</td>
    </tr>
    <tr>
      <th>France</th>
      <td>209024.050</td>
    </tr>
  </tbody>
</table>
</div>



UK alone results in 82% of total $ revenue which is expected for a UK based retailer.

The senior management for the retail company should consider expanding to the other countries (fter UK) where they have significant sales such as Neatherland, EIRE, Germany & France for future geographic expansion.


```python

```
